package cn.liushuai.util;

import lombok.Data;
import lombok.ToString;

@Data
@ToString
public class MyUtil {
    Integer sid;
    String stext;
}
