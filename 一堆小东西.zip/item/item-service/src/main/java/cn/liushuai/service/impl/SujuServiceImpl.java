package cn.liushuai.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import cn.liushuai.entity.Suju;
import cn.liushuai.service.SujuService;
import cn.liushuai.mapper.SujuMapper;
import org.springframework.stereotype.Service;

/**
* @author Lenovo
* @description 针对表【suju】的数据库操作Service实现
* @createDate 2023-07-03 17:30:09
*/
@Service
public class SujuServiceImpl extends ServiceImpl<SujuMapper, Suju>
    implements SujuService{

}




