package cn.liushuai.service;

import cn.liushuai.entity.Suju;
import com.baomidou.mybatisplus.extension.service.IService;

/**
* @author Lenovo
* @description 针对表【suju】的数据库操作Service
* @createDate 2023-07-03 17:30:09
*/
public interface SujuService extends IService<Suju> {

}
