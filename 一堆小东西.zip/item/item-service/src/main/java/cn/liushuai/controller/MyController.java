package cn.liushuai.controller;

import cn.liushuai.entity.Suju;
import cn.liushuai.service.SujuService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
//file:///C:/Users/Lenovo/Desktop/文件/Dome/NO.SEVEN/home.html
//file:///C:/Users/Lenovo/Desktop/%E6%96%87%E4%BB%B6/Dome/NO.SEVEN/home.html
@CrossOrigin(origins = "http://localhost:8080",allowCredentials = "true")
public class MyController {
    
    @Autowired
    SujuService service;


    @GetMapping("/masktwo")
    public List<Suju> masktwo (){
        List<Suju> date = service.list();
        return date;
    }

}
