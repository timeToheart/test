package cn.liushuai.mapper;

import cn.liushuai.entity.Suju;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
* @author Lenovo
* @description 针对表【suju】的数据库操作Mapper
* @createDate 2023-07-03 17:30:09
* @Entity cn.liushuai.entity.Suju
*/
public interface SujuMapper extends BaseMapper<Suju> {

}




