package com.bjsxt.plane;

import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

/*
 * 游戏主窗口
 * */
public class MyGameFrame extends Frame {

    Image plane = Gameutil.getImage("image/plane.png");
    Image bg = Gameutil.getImage("image/bj.png");

    @Override
    public void paint(Graphics g) {//g当做是一支画笔
        // 画入背景图
        g.drawImage(bg,0,0,500,500,null);
        // 画入飞机图
        g.drawImage(plane,100,100,22,33,null);




    }

    //初始化窗口
    public void launchFrame(){
        // 设置窗口名字
        this.setTitle("飞机大战");
        // 设置窗口是否可见
        setVisible(true);
        // 设置窗口大小
        setSize(500,500);
        // 设置窗口打开的位置
        setLocation(100,100);
        // 设置增加关闭窗口的动作
        this.addWindowListener(new WindowAdapter() {
            @Override
            public void windowOpened(WindowEvent e) {
                System.exit(0);//正常退出程序
            }
        });
    }
    /*
    * 定义了一个重画窗口的线程类
    * 定义成内部类是为了方便直接使用窗口类的相关方法属性
    * */
    class PaintThread extends Thread{
        @Override
        public void run(){
            while (true){
                repaint();//内部类可以直接使用外部类的成员
                try {
                    Thread.sleep(50);
                } catch (InterruptedException e) {
                    throw new RuntimeException(e);
                }
            }
        }
    }

    public static void main(String[] args) {
        // 实例化对象
        MyGameFrame gameFrame = new MyGameFrame();
        // 运行程序
        gameFrame.launchFrame();
    }

}
