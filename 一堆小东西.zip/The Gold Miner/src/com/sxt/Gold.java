package com.sxt;

import java.awt.*;

public class Gold extends Object{
    Gold(){
        this.x = 300;
        this.y = 500;
        this.width = 52;
        this.height = 52;
        this.img = Toolkit.getDefaultToolkit().createImage("imgs/gold1.gif");
    }
}
