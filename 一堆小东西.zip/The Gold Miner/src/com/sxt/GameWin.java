package com.sxt;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class GameWin extends JFrame {
    // 实例化对象
    Bg bg = new Bg();
    Line line = new Line();
    Gold gold = new Gold();
    Image offScreenImage;
    // 初始化游戏
    void launch(){
        //设置窗口是否可见
        this.setVisible(true);
        //设置窗口大小
        this.setSize(768,1000);
        //设置窗口居中
        this.setLocationRelativeTo(null);
        //设置标题
        this.setTitle("黄金矿工");
        //设置释放窗体
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e);
                if(e.getButton()==1){
                    line.state=1;
                }
            }
        });


        // 循环载入
        while (true){
            repaint();
            try {
                Thread.sleep(5);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
        }
    }

    @Override
    public void paint(Graphics g) {
        offScreenImage = this.createImage(768,1000);
        Graphics gImage = offScreenImage.getGraphics();

        bg.paintSelf(g);
        line.paintSelf(g);
        gold.paintSelf(g);

        g.drawImage(offScreenImage,0,0,null);
    }

    public static void main(String[] args) {
        GameWin gameWin = new GameWin();
        gameWin.launch();
    }


}
